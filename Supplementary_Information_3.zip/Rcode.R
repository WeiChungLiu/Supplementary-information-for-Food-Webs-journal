setwd('path/to/your/working/dir')


library(igraph)
library(stringr)
library(corrr)
library(ggplot2)
library(ggdendro)
library(fundiversity)


i = 1 # which network (1~92)

############# topological centralities ###########

network  <- read_graph(str_c("FoodWebs/FW", i, ".txt"), format = "dl")

undirectNetwork <- as.undirected(network, mode = "collapse")
directNetwork <- as.directed(network, mode = "arbitrary")

DC <-
  as.numeric(degree(undirectNetwork, mode = "all")[order(names(degree(undirectNetwork, mode = "all")))])

BC <-
  as.numeric(betweenness(undirectNetwork, directed = F)[order(names(betweenness(undirectNetwork, directed = F)))])

CC <-
  as.numeric(closeness(undirectNetwork, mode = "total")[order(names(closeness(undirectNetwork, mode = "total")))])

AC <-
  as.numeric(alpha.centrality(undirectNetwork)[order(names(alpha.centrality(undirectNetwork)))])

EC <-
  as.numeric(eigen_centrality(undirectNetwork, directed = F)$vector[order(names(eigen_centrality(undirectNetwork, directed = F)$vector))])

KNN <-
  as.numeric(knn(
    undirectNetwork,
    mode = "total",
    neighbor.degree.mode = "total"
  )$knn[order(names(
    knn(
      undirectNetwork,
      mode = "total",
      neighbor.degree.mode = "total"
    )$knn
  ))])

HC <-
  as.numeric(harmonic_centrality(undirectNetwork, mode = "total")[order(names(harmonic_centrality(undirectNetwork, mode = "total")))])

KC <-
  as.numeric(hub_score(undirectNetwork)$vector[order(names(hub_score(undirectNetwork)$vector))])



write.table(
  "ID,Degree,Betweenness,Closeness,Alpha_Centrality,Eigen_centrality,KNN,Harmonic_centrality,Kleinberg's hub centrality",
  
  file = str_c("FW", i, "_centrality.csv"),
  sep = ",",
  append = T,
  col.names = FALSE,
  row.names = FALSE,
  quote = FALSE
  
)
sortedNames <- V(network)$name[order(V(network)$name)]

write.table(
  paste0(
    sortedNames,
    ",",
    DC,
    ",",
    BC,
    ",",
    CC,
    ",",
    AC,
    ",",
    EC,
    ",",
    KNN,
    ",",
    HC,
    ",",
    KC
  ),
  
  
  file = str_c("FW", i, "_centrality.csv"),
  sep = ",",
  append = T,
  col.names = FALSE,
  row.names = FALSE,
  quote = FALSE
  
)


###### dendrogram ###########

topoIndex <-
  read.csv(str_c("FW", i, "_centrality.csv"),
           row.names = 1)
topoIndex <- topoIndex[, -c(9)]
cc <-
  cor(topoIndex, use = "pairwise.complete.obs", method = "kendall")



png(str_c(i, ".png"), width = 960, height = 720)

hc <- hclust(dist(cc))
plot(
  ggdendrogram(
    hc,
    rotate = T,
    theme_dendro = T,
    labels = T
  ) + ggtitle(str_c("FW", i))
  + labs(x = "Speices", y = NULL)
  + theme(
    axis.title.x = element_text(size = 20),
    axis.text.x  = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    axis.text.y  = element_text(size = 20),
    plot.title = element_text(size = 20),
  )
)
dev.off()


### functional diversity ############

trait <- read.csv(str_c("FW", i, "_centrality.csv"),  row.names = 1)
trait <- as.matrix(trait)
trait <- trait[,c(1,2,4,5)]  ####### choose centralities ########





raoValue <- fd_raoq(trait)
fdis <- fd_fdis(trait)
feve <- fd_feve(trait)
fric <- fd_fric(trait)


write.table(
  "ID,Rao’Q,Dispersion,Evenness,Richness\n",
  
  file = str_c("FW", i, "_diversity.csv"),
  sep = ",",
  append = T,
  col.names = FALSE,
  row.names = FALSE,
  quote = FALSE,
  
  
  paste0(
    str_c("FW", i),
    ",",
    raoValue$Q,
    ",",
    fdis$FDis,
    ",",
    feve$FEve,
    ",",
    fric$FRic
  )
)
