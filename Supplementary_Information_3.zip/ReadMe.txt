This R code is a program for quantifying the network-based functional diversity indices for a given food web. 

It requires the user to input a food web data in a format of edge list (i.e., who is eaten by whom) via a valid path to 
a text file that contains the food web data. 

The program then calculates eight centrality indices by using R package "igraph", those indices are: 
degree centrality (DC), 
betweenness centrality (BC), 
closeness centrality (CC), 
alpha centrality (AC), 
eigenvector centrality (EC), 
average nearest neighbor degree (KNN), 
harmonic centrality (HC), 
and Kleinberg's centrality (KC). 

The program then constructs a cluster tree showing the relationship between those eight centrality indices. 

The user can choose any indices for the subsequent functional diversity analysis. But here, in this demonstrative program, 
as in our paper, we avoid using redundant centrality indices, and we choose DC, BC, EC and AC as four network traits. 

By using R package "fundiversity", the program then calculates network-based functional richness, evenness, dispersion, and Rao’Q, and outputs their values. 